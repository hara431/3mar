package app.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.awt.print.Book;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import app.Application;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebIntegrationTest
public class TestControllerTest {

  //Required to Generate JSON content from Java objects
  public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  //Test RestTemplate to invoke the APIs.
  private RestTemplate restTemplate = new TestRestTemplate();
  
  @Test
  public void testloginApi() throws JsonProcessingException{

    //Building the Request body data
    Map<String, Object> requestBody = new HashMap<String, Object>();
    requestBody.put("username", "test");
    requestBody.put("password", "test");
    HttpHeaders requestHeaders = new HttpHeaders();
    requestHeaders.setContentType(MediaType.APPLICATION_JSON);

    //Creating http entity object with request body and headers
    HttpEntity<String> httpEntity =
        new HttpEntity<String>(OBJECT_MAPPER.writeValueAsString(requestBody), requestHeaders);

    //Invoking the API
    Map<String, Object> apiResponse =
        restTemplate.postForObject("http://localhost:8888/login", httpEntity, Map.class, Collections.EMPTY_MAP);

    assertNotNull(apiResponse);

    //Asserting the response of the API.
    String message = apiResponse.get("message").toString();
    assertEquals("login successfully", message);
    String bookId = ((Map<String, Object>)apiResponse.get("book")).get("id").toString();

    assertNotNull(bookId);


  }

}